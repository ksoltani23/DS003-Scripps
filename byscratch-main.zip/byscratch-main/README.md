# byscratch
Refactoring code from our textbook to work on Colab and with relative imports
